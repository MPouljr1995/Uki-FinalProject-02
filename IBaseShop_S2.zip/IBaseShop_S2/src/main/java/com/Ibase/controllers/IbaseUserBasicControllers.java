package com.Ibase.controllers;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Ibase.model.IbaseUser;
import com.Ibase.services.IbaseUserBaicServices;

@RestController
@RequestMapping("/api/auth//user")
public class IbaseUserBasicControllers {
	
	@Autowired
	IbaseUserBaicServices ibaseUserBaicServices;
	
	@GetMapping
	public ResponseEntity<Map<String, Object>> viewAllUsers(
			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
		System.out.println("ViewAllUsers");
		return ibaseUserBaicServices.viewAllUsers(pageNo, pageSize, sortBy);
	}
	
	@GetMapping("/{userid}")
	public ResponseEntity<Optional<IbaseUser>> viewUserById(@PathVariable String userid) {
		System.out.println("ViewUserById");
		return ibaseUserBaicServices.viewUserById(userid);
	}
	
	@DeleteMapping("/{userid}")
	public ResponseEntity<String> deleteUserById(@PathVariable String userid) {
		System.out.println("DeleteUserById");
		return ibaseUserBaicServices.deleteUserById(userid);
	}
	
	@PutMapping("/{userid}")
	public ResponseEntity<IbaseUser> updateUserById(@PathVariable String userid, @RequestBody IbaseUser updateUser) {
		System.out.println("UpdateUserById");
		return ibaseUserBaicServices.updateUserById(userid,updateUser);
	}

}
